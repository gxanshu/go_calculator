#Testing Eval based calculator writing in Go BTW
